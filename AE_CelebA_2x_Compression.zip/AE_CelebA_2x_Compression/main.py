from model import *
from data import *

#os.environ["CUDA_VISIBLE_DEVICES"] = "0"


data_gen_args = dict(rotation_range=0.2,
                    width_shift_range=0.05,
                    height_shift_range=0.05,
                    shear_range=0.05,
                    zoom_range=0.05,
                    horizontal_flip=True,
                    fill_mode='nearest')
myGene = trainGenerator(50,'data','train','train',data_gen_args,target_size = (218,178),save_to_dir = None)

model = unet(input_size=(218,178,3))
model_checkpoint = ModelCheckpoint('align_celebA_2x_AE_model.hdf5', monitor='loss',verbose=1, save_best_only=True)
model_EarlyStopping = EarlyStopping(monitor='loss', min_delta=0, patience=3, verbose=1, mode='auto', baseline=None, restore_best_weights=True)

import tensorflow as tf
def scheduler(epoch, lr):
    if epoch < 3:
        return lr
    else:
        return lr * tf.math.exp(-0.1)

lr_callback = tf.keras.callbacks.LearningRateScheduler(scheduler)
print('Initial Learning-rate: ',round(model.optimizer.lr.numpy(), 5))

model.fit_generator(myGene,steps_per_epoch=1000,epochs=2,callbacks=[model_checkpoint,model_EarlyStopping,lr_callback])
print('Final Learning-rate: ',round(model.optimizer.lr.numpy(), 5))

testGene = testGenerator("data/test",target_size = (218,178),num_image = 24,flag_multi_class = True,as_gray = False)
results = model.predict_generator(testGene,30,verbose=1)
# results = (255*results).astype(np.uint8)
saveResult("data/test",results)

from matplotlib import pyplot as plt

plt.imshow(np.squeeze(results[0,:,:,:]))
plt.show()